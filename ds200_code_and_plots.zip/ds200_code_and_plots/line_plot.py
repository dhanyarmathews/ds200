import pandas as pd
import matplotlib.pyplot as pyplot

pyplot.ion()
# Read data from .CSV file to a dataframe
values = pd.read_csv('J:\iisc\ds_200\Statewisedatasupto_dipp.csv', header=0, index_col=0, parse_dates=True, squeeze=True)
# Drop the last row, i.e, the total count
values.drop(values.tail(1).index,inplace=True)
# Plot the values
values.plot()
pyplot.title('Line Plot - Statewise data of employment');
pyplot.xlabel('Name_of_the_State')
pyplot.ylabel('Statewise_data')
pyplot.xticks(range(len(values.index)), values.index)
#pyplot.show()
pyplot.savefig('lineplot.png')