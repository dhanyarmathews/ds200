import pandas as pd
import matplotlib.pyplot as pyplot

pyplot.ion()
# Read data from .CSV file to a dataframe
values = pd.read_csv('J:\iisc\ds_200\Statewisedatasupto_dipp.csv', header=0, index_col=0, parse_dates=True, squeeze=True)
# Drop the last row, i.e, the total count
values.drop(values.tail(1).index,inplace=True)
# Plot the values
#values.boxplot(column=['NUMBER'])#, 'INVESTMENT', 'EMPLOYMENT'])
values.boxplot(column=['NUMBER', 'INVESTMENT', 'EMPLOYMENT'],grid=False, rot=45, fontsize=15)
pyplot.title('Box Plot - Number Of Industries vs Investment vs Employment');
pyplot.savefig('boxplot.png')